package steps;

import static org.junit.Assert.fail;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.annotations.findby.By;

public class MercedesHome_Steps {
	WebDriver driver;

	@Given("Mercedes-benz {string} homepage")
	public void mercedes_benz_homepage(String string) {
		System.setProperty("webdriver.chrome.driver", "webdrivers/chromedriver");
		driver = new ChromeDriver();
		String homeUrl = "https://www.mercedes-benz.co.";
		String str = string;
		switch (str) {
		case "UK":
			driver.get(homeUrl + "uk/");
			driver.manage().window().maximize();
			break;
		//add other possibilities
		default:
			System.out.println("no match");
		}
	}

	@Given("agree to all cookies")
	public void agree_to_all_cookies() {
		driver.findElement(org.openqa.selenium.By.id("uc-btn-accept-banner")).click();
	    
	}
	
	@Given("the title Our models is present")
	public void the_title_Our_models_is_present() {
		driver.switchTo().frame("vmos-cont");
		if( !driver.findElement(By.className("vmos_3zIAO")).getText().equals("Our models")) {
			fail("Page does not match especifications");	
		} 
	}
	
	@Given("click on model {string}")
	public void model_is_selected(String string) {
		String str = string;
		String text = null;
		switch (str) {
		case "Hatchbacks":
			driver.findElements(By.className("vmos_3KSbz")).get(0).click();
			text = string;
			break;
		default:
			System.out.println("no match");
		}
		driver.findElement(By.buttonText(text)).click();
	}
	
	@When("build an A Class car")
	public void build_an_A_Class_car() {
		Actions actions = new Actions(driver);
		WebElement aClass = driver.findElement(By.className("vmos_jQyeG"));
		actions.moveToElement(aClass).perform();
		
		
		//findElement(By.linkText("Build your car")).click();

	}
	
	@Then("navigate to car configuration page")
	public void navigate_to_car_configuration_page() {
		//could not find a way to select "Build your car", needed more time.
		driver.get("https://www.mercedes-benz.co.uk/passengercars/mercedes-benz-cars/car-configurator.html/motorization/CCci/GB/en/A-KLASSE/KOMPAKT-LIMOUSINE");
		String expUrl = "https://www.mercedes-benz.co.uk/passengercars/mercedes-benz-cars/car-configurator.html/motorization/CCci/GB/en/A-KLASSE/KOMPAKT-LIMOUSINE";
		String actUrl = driver.getCurrentUrl();
		if(!expUrl.equals(actUrl)) {
			fail("Page does not match especifications");	
			
		}
	    
	}
	
	@Then("select Fuel as {string}")
	public void select_Fuel_as(String string) {
		driver.switchTo().frame("vmos-cont");
		String str = string;
		switch (str) {
		case "Diesel":
			driver.findElement(By.xpath("//body/main[1]/div[1]/div[1]/div[1]/owcc[1]/cc-app-root[1]/div[1]/cc-app-container[1]/div[1]/div[2]/div[2]/div[1]/cc-motorization[1]/cc-motorization-filters-section[1]/cc-motorization-filters[1]/form[1]/fieldset[1]/div[2]/div[2]/wb-checkbox-control[1]/label[1]/wb-icon[1]")).click();
			break;
		//add other possibilities
		default:
			System.out.println("no match");
		}
		driver.quit();
	}
	
	
}
