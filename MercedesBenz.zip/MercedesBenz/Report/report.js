$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:features/MercedesHome.feature");
formatter.feature({
  "name": "Mercedes challenge",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Build an Hatchback: A class car",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@regression"
    }
  ]
});
formatter.step({
  "name": "Mercedes-benz \"UK\" homepage",
  "keyword": "Given "
});
formatter.match({
  "location": "steps.MercedesHome_Steps.mercedes_benz_homepage(java.lang.String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "agree to all cookies",
  "keyword": "And "
});
formatter.match({
  "location": "steps.MercedesHome_Steps.agree_to_all_cookies()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the title Our models is present",
  "keyword": "And "
});
formatter.match({
  "location": "steps.MercedesHome_Steps.the_title_Our_models_is_present()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on model \"Hatchbacks\"",
  "keyword": "When "
});
formatter.match({
  "location": "steps.MercedesHome_Steps.model_is_selected(java.lang.String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "build an A Class car",
  "keyword": "And "
});
formatter.match({
  "location": "steps.MercedesHome_Steps.build_an_A_Class_car()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "navigate to car configuration page",
  "keyword": "Then "
});
formatter.match({
  "location": "steps.MercedesHome_Steps.navigate_to_car_configuration_page()"
});
formatter.result({
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"xpath\",\"selector\":\"//body/div[1]/vmos[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/section[1]/div[1]/div[2]/div[1]/div[2]/div[1]/ul[1]/li[2]/a[1]\"}\n  (Session info: chrome\u003d91.0.4472.77)\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-SH1QRR7\u0027, ip: \u0027192.168.1.74\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u002714.0.1\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 91.0.4472.77, chrome: {chromedriverVersion: 91.0.4472.19 (1bf021f248676..., userDataDir: C:\\Users\\35196\\AppData\\Loca...}, goog:chromeOptions: {debuggerAddress: localhost:65416}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true}\nSession ID: dc3d3e4a826451a630efaad51788dfe6\n*** Element info: {Using\u003dxpath, value\u003d//body/div[1]/vmos[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/section[1]/div[1]/div[2]/div[1]/div[2]/div[1]/ul[1]/li[2]/a[1]}\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.base/java.lang.reflect.Constructor.newInstanceWithCaller(Constructor.java:500)\r\n\tat java.base/java.lang.reflect.Constructor.newInstance(Constructor.java:481)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:428)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat steps.MercedesHome_Steps.navigate_to_car_configuration_page(MercedesHome_Steps.java:77)\r\n\tat ✽.navigate to car configuration page(file:///C:/Testes%20Automáticos/MercedesBenz/features/MercedesHome.feature:13)\r\n",
  "status": "failed"
});
});